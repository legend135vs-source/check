import os
from pathlib import Path
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.ai_prompt import AIPrompt

TEMPLATES_DIR = Path(__file__).parent / "templates"


class PromptBuilder:
    def __init__(self, db: Optional[AsyncSession] = None):
        self.db = db

    async def build(self, key: str, context: dict) -> str:
        template = await self._load_template(key)
        for k, v in context.items():
            template = template.replace(f"{{{{{k}}}}}", str(v))
        return template

    async def _load_template(self, key: str) -> str:
        if self.db:
            result = await self.db.execute(
                select(AIPrompt).where(AIPrompt.key == key, AIPrompt.is_active == True)
            )
            prompt = result.scalar_one_or_none()
            if prompt:
                return prompt.template

        file_path = TEMPLATES_DIR / f"{key}.txt"
        if file_path.exists():
            return file_path.read_text()

        raise ValueError(f"Prompt template not found for key: {key}")
