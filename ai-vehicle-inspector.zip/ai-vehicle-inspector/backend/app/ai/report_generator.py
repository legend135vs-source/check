from openai import AsyncOpenAI
from app.core.config import settings
from app.ai.prompt_builder import PromptBuilder
import json
import structlog

logger = structlog.get_logger()


class ReportGenerator:
    def __init__(self, prompt_builder: PromptBuilder):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)
        self.prompt_builder = prompt_builder

    async def generate(self, context: dict) -> dict:
        prompt = await self.prompt_builder.build("full_report", context)
        try:
            response = await self.client.chat.completions.create(
                model=settings.OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": "You are an expert vehicle inspector AI. Return JSON only."},
                    {"role": "user", "content": prompt},
                ],
                max_tokens=settings.OPENAI_MAX_TOKENS,
                response_format={"type": "json_object"},
            )
            return json.loads(response.choices[0].message.content)
        except Exception as e:
            logger.error("report_generation_failed", error=str(e))
            return {"error": str(e), "summary": "Report generation failed"}
