from typing import List
from openai import AsyncOpenAI
import base64
from app.core.config import settings
from app.domain.entities.photo_analysis import PhotoAnalysisResult, DamageItem
import structlog

logger = structlog.get_logger()


class VisionAnalyzer:
    def __init__(self):
        self.client = AsyncOpenAI(api_key=settings.OPENAI_API_KEY)

    async def analyze_batch(self, photo_bytes_list: List[bytes]) -> List[PhotoAnalysisResult]:
        results = []
        for photo_bytes in photo_bytes_list:
            result = await self._analyze_single(photo_bytes)
            results.append(result)
        return results

    async def _analyze_single(self, photo_bytes: bytes) -> PhotoAnalysisResult:
        b64 = base64.b64encode(photo_bytes).decode()
        try:
            response = await self.client.chat.completions.create(
                model=settings.OPENAI_VISION_MODEL,
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {
                                "type": "text",
                                "text": "Analyze this vehicle photo. Identify all visible damage. Return JSON: {damages: [{area, severity, description}], overall_condition, ai_notes}",
                            },
                            {
                                "type": "image_url",
                                "image_url": {"url": f"data:image/jpeg;base64,{b64}"},
                            },
                        ],
                    }
                ],
                max_tokens=1000,
                response_format={"type": "json_object"},
            )
            import json
            data = json.loads(response.choices[0].message.content)
            damages = [DamageItem(**d) for d in data.get("damages", [])]
            return PhotoAnalysisResult(
                photo_url="",
                damages=damages,
                overall_condition=data.get("overall_condition", "unknown"),
                ai_notes=data.get("ai_notes", ""),
            )
        except Exception as e:
            logger.error("vision_analysis_failed", error=str(e))
            return PhotoAnalysisResult(photo_url="", damages=[], overall_condition="unknown", ai_notes="Analysis failed")
