from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.services.admin_service import AdminService

router = APIRouter()


@router.get("/stats")
async def get_stats(db: AsyncSession = Depends(get_db)):
    service = AdminService(db)
    return await service.get_stats()


@router.get("/brands")
async def list_brands(db: AsyncSession = Depends(get_db)):
    service = AdminService(db)
    return await service.list_brands()


@router.get("/prompts")
async def list_prompts(db: AsyncSession = Depends(get_db)):
    service = AdminService(db)
    return await service.list_prompts()
