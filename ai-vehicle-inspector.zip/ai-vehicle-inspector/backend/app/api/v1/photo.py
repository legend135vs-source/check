from fastapi import APIRouter, UploadFile, File, Depends
from typing import List
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.schemas.photo import PhotoAnalysisResponse
from app.services.photo_service import PhotoService

router = APIRouter()


@router.post("/analyze", response_model=PhotoAnalysisResponse)
async def analyze_photos(
    photos: List[UploadFile] = File(...),
    db: AsyncSession = Depends(get_db),
):
    service = PhotoService(db)
    return await service.analyze(photos)
