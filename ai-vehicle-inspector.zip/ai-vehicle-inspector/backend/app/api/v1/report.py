from uuid import UUID
from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.schemas.report import ReportCreateRequest, ReportResponse, ReportStatusResponse
from app.services.report_service import ReportService

router = APIRouter()


@router.post("", response_model=ReportStatusResponse, status_code=202)
async def create_report(
    body: ReportCreateRequest,
    db: AsyncSession = Depends(get_db),
):
    service = ReportService(db)
    return await service.create_report(body)


@router.get("/{report_id}", response_model=ReportResponse)
async def get_report(
    report_id: UUID,
    db: AsyncSession = Depends(get_db),
):
    service = ReportService(db)
    return await service.get_report(report_id)
