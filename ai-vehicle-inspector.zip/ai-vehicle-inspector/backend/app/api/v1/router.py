from fastapi import APIRouter
from app.api.v1 import report, vin, photo, vehicle, health
from app.core.config import settings

api_router = APIRouter()

api_router.include_router(health.router, tags=["health"])
api_router.include_router(report.router, prefix="/report", tags=["report"])
api_router.include_router(vin.router, prefix="/vin", tags=["vin"])
api_router.include_router(photo.router, prefix="/photo", tags=["photo"])
api_router.include_router(vehicle.router, prefix="/vehicle", tags=["vehicle"])

# Hidden admin route
from app.api.v1 import admin
api_router.include_router(admin.router, prefix=f"/{settings.ADMIN_SECRET_PATH}", tags=["admin"])
