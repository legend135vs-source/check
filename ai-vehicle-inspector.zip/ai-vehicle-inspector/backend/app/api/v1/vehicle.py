from fastapi import APIRouter, Query, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.schemas.vehicle import VehicleSearchResponse
from app.services.vehicle_service import VehicleService

router = APIRouter()


@router.get("/search", response_model=VehicleSearchResponse)
async def search_vehicle(
    q: str = Query(..., min_length=2),
    db: AsyncSession = Depends(get_db),
):
    service = VehicleService(db)
    return await service.search(q)
