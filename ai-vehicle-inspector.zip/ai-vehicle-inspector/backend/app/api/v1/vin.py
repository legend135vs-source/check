from fastapi import APIRouter, Depends
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_db
from app.schemas.vin import VINDecodeResponse
from app.services.vin_service import VINService

router = APIRouter()


@router.get("/{vin}", response_model=VINDecodeResponse)
async def decode_vin(vin: str, db: AsyncSession = Depends(get_db)):
    service = VINService(db)
    return await service.decode(vin)
