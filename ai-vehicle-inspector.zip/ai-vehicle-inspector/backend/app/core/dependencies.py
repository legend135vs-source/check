from typing import AsyncGenerator
from sqlalchemy.ext.asyncio import AsyncSession
from app.core.database import AsyncSessionLocal
from app.infrastructure.cache.redis_cache import RedisCache
from app.infrastructure.storage.r2_storage import R2Storage
from app.core.config import settings


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    async with AsyncSessionLocal() as session:
        yield session


def get_cache() -> RedisCache:
    return RedisCache(settings.REDIS_URL)


def get_storage() -> R2Storage:
    return R2Storage(
        account_id=settings.R2_ACCOUNT_ID,
        access_key=settings.R2_ACCESS_KEY_ID,
        secret_key=settings.R2_SECRET_ACCESS_KEY,
        bucket=settings.R2_BUCKET_NAME,
        public_url=settings.R2_PUBLIC_URL,
    )
