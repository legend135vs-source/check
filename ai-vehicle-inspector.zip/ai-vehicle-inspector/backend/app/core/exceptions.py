from fastapi import HTTPException, status


class VINNotFoundError(HTTPException):
    def __init__(self, vin: str):
        super().__init__(status_code=status.HTTP_404_NOT_FOUND, detail=f"VIN {vin} not found")


class ReportNotFoundError(HTTPException):
    def __init__(self, report_id: str):
        super().__init__(status_code=status.HTTP_404_NOT_FOUND, detail=f"Report {report_id} not found")


class AIServiceError(HTTPException):
    def __init__(self, detail: str = "AI service error"):
        super().__init__(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=detail)


class StorageError(HTTPException):
    def __init__(self, detail: str = "Storage error"):
        super().__init__(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=detail)
