from dataclasses import dataclass, field
from typing import List, Dict


@dataclass
class DamageItem:
    area: str
    severity: str  # none | minor | moderate | severe
    description: str


@dataclass
class PhotoAnalysisResult:
    photo_url: str
    damages: List[DamageItem] = field(default_factory=list)
    overall_condition: str = "unknown"
    ai_notes: str = ""
