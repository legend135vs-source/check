from dataclasses import dataclass, field
from datetime import datetime
from uuid import UUID
from typing import Optional


@dataclass
class ReportEntity:
    id: UUID
    vin: Optional[str]
    auto_ria_url: Optional[str]
    status: str  # pending | processing | done | failed
    risk_score: Optional[int]
    pdf_url: Optional[str]
    ai_summary: Optional[str]
    created_at: datetime
    updated_at: datetime
