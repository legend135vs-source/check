from dataclasses import dataclass
from typing import Optional


@dataclass
class VehicleEntity:
    id: str
    vin: Optional[str]
    make: str
    model: str
    year: int
    engine: Optional[str]
    transmission: Optional[str]
    fuel_type: Optional[str]
    body_type: Optional[str]
    mileage: Optional[int]
    country_of_origin: Optional[str]
