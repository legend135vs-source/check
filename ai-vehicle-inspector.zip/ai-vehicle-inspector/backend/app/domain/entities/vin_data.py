from dataclasses import dataclass
from typing import Optional


@dataclass
class VINData:
    vin: str
    make: Optional[str]
    model: Optional[str]
    year: Optional[int]
    engine: Optional[str]
    transmission: Optional[str]
    fuel_type: Optional[str]
    body_type: Optional[str]
    country: Optional[str]
    raw_data: dict
