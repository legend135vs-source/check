from abc import ABC, abstractmethod
from typing import List
from app.domain.entities.vin_data import VINData
from app.domain.entities.photo_analysis import PhotoAnalysisResult


class IAIService(ABC):
    @abstractmethod
    async def analyze_photos(self, photo_urls: List[str]) -> List[PhotoAnalysisResult]:
        ...

    @abstractmethod
    async def generate_report(self, context: dict) -> dict:
        ...
