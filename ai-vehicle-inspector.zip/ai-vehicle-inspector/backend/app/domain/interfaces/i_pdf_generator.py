from abc import ABC, abstractmethod


class IPDFGenerator(ABC):
    @abstractmethod
    async def generate(self, report_data: dict) -> bytes:
        ...
