from abc import ABC, abstractmethod
from uuid import UUID
from typing import Optional
from app.domain.entities.report import ReportEntity


class IReportRepository(ABC):
    @abstractmethod
    async def create(self, report: ReportEntity) -> ReportEntity:
        ...

    @abstractmethod
    async def get_by_id(self, report_id: UUID) -> Optional[ReportEntity]:
        ...

    @abstractmethod
    async def update(self, report: ReportEntity) -> ReportEntity:
        ...
