from abc import ABC, abstractmethod


class IStorage(ABC):
    @abstractmethod
    async def upload(self, key: str, data: bytes, content_type: str) -> str:
        ...

    @abstractmethod
    async def get_url(self, key: str) -> str:
        ...
