import json
from typing import Optional, Any
import redis.asyncio as aioredis
from app.domain.interfaces.i_cache import ICache
import structlog

logger = structlog.get_logger()


class RedisCache(ICache):
    def __init__(self, redis_url: str):
        self.redis_url = redis_url
        self._client: Optional[aioredis.Redis] = None

    async def _get_client(self) -> aioredis.Redis:
        if not self._client:
            self._client = await aioredis.from_url(self.redis_url)
        return self._client

    async def get(self, key: str) -> Optional[Any]:
        try:
            client = await self._get_client()
            value = await client.get(key)
            return json.loads(value) if value else None
        except Exception as e:
            logger.warning("cache_get_failed", key=key, error=str(e))
            return None

    async def set(self, key: str, value: Any, ttl: int = 3600) -> None:
        try:
            client = await self._get_client()
            await client.setex(key, ttl, json.dumps(value))
        except Exception as e:
            logger.warning("cache_set_failed", key=key, error=str(e))

    async def delete(self, key: str) -> None:
        try:
            client = await self._get_client()
            await client.delete(key)
        except Exception as e:
            logger.warning("cache_delete_failed", key=key, error=str(e))
