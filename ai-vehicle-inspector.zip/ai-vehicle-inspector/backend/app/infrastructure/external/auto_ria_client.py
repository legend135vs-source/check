import httpx
from app.core.config import settings
import structlog

logger = structlog.get_logger()


class AutoRiaClient:
    def __init__(self):
        self.api_key = settings.AUTO_RIA_API_KEY
        self.base_url = settings.AUTO_RIA_API_URL

    async def get_vehicle_info(self, url: str) -> dict:
        # Auto.ria URL parsing logic
        # Extract vehicle ID from URL and call API
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                params = {"api_key": self.api_key}
                response = await client.get(f"{self.base_url}/info", params=params)
                response.raise_for_status()
                return response.json()
        except Exception as e:
            logger.error("auto_ria_fetch_failed", url=url, error=str(e))
            return {}
