import httpx
from app.core.config import settings
import structlog

logger = structlog.get_logger()


class VINDecoderClient:
    BASE_URL = "https://vpic.nhtsa.dot.gov/api/vehicles"

    async def decode(self, vin: str) -> dict:
        url = f"{self.BASE_URL}/decodevin/{vin}?format=json"
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                response = await client.get(url)
                response.raise_for_status()
                data = response.json()
                results = {r["Variable"]: r["Value"] for r in data.get("Results", []) if r.get("Value")}
                return results
        except Exception as e:
            logger.error("vin_decode_failed", vin=vin, error=str(e))
            return {}
