import uuid
from typing import Optional
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.models.report import Report
from app.domain.interfaces.i_report_repository import IReportRepository
from app.domain.entities.report import ReportEntity


class ReportRepository(IReportRepository):
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_by_id(self, report_id: uuid.UUID) -> Optional[Report]:
        result = await self.db.execute(select(Report).where(Report.id == report_id))
        return result.scalar_one_or_none()

    async def create(self, report: ReportEntity) -> ReportEntity:
        raise NotImplementedError

    async def update(self, report: ReportEntity) -> ReportEntity:
        raise NotImplementedError
