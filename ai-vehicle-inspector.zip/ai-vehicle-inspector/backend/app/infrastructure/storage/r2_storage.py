import boto3
from botocore.config import Config
from app.domain.interfaces.i_storage import IStorage
import structlog

logger = structlog.get_logger()


class R2Storage(IStorage):
    def __init__(self, account_id: str, access_key: str, secret_key: str, bucket: str, public_url: str):
        self.bucket = bucket
        self.public_url = public_url
        self.client = boto3.client(
            "s3",
            endpoint_url=f"https://{account_id}.r2.cloudflarestorage.com",
            aws_access_key_id=access_key,
            aws_secret_access_key=secret_key,
            config=Config(signature_version="s3v4"),
        )

    async def upload(self, key: str, data: bytes, content_type: str = "application/octet-stream") -> str:
        try:
            self.client.put_object(Bucket=self.bucket, Key=key, Body=data, ContentType=content_type)
            return await self.get_url(key)
        except Exception as e:
            logger.error("r2_upload_failed", key=key, error=str(e))
            raise

    async def get_url(self, key: str) -> str:
        return f"{self.public_url}/{key}"
