from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy import String, Text, Boolean
from app.models.base import Base, UUIDMixin, TimestampMixin


class AIPrompt(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "ai_prompts"

    key: Mapped[str] = mapped_column(String(100), unique=True, nullable=False)
    description: Mapped[str | None] = mapped_column(String(500))
    template: Mapped[str] = mapped_column(Text, nullable=False)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    version: Mapped[int] = mapped_column(default=1)
