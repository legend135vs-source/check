import uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, Integer, ForeignKey, Date
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.models.base import Base, UUIDMixin, TimestampMixin


class AuctionRecord(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "auction_records"

    report_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("reports.id"))
    auction_name: Mapped[str | None] = mapped_column(String(200))
    lot_number: Mapped[str | None] = mapped_column(String(100))
    sale_date: Mapped[str | None] = mapped_column(String(50))
    odometer: Mapped[int | None] = mapped_column(Integer)
    damage_description: Mapped[str | None] = mapped_column(String(1000))
    primary_damage: Mapped[str | None] = mapped_column(String(200))
    secondary_damage: Mapped[str | None] = mapped_column(String(200))
    sale_price: Mapped[int | None] = mapped_column(Integer)
    photos: Mapped[list | None] = mapped_column(JSONB)

    report: Mapped["Report"] = relationship("Report", back_populates="auction_records")
