import uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from app.models.base import Base, UUIDMixin, TimestampMixin


class Model(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "models"

    brand_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("brands.id"), nullable=False)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    year_from: Mapped[int | None]
    year_to: Mapped[int | None]
    is_active: Mapped[bool] = mapped_column(default=True)

    brand: Mapped["Brand"] = relationship("Brand", back_populates="models")
