import uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.models.base import Base, UUIDMixin, TimestampMixin


class PhotoAnalysis(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "photo_analyses"

    report_id: Mapped[uuid.UUID] = mapped_column(UUID(as_uuid=True), ForeignKey("reports.id"))
    photo_url: Mapped[str] = mapped_column(String(1000))
    damage_json: Mapped[dict | None] = mapped_column(JSONB)
    overall_condition: Mapped[str | None] = mapped_column(String(50))
    ai_notes: Mapped[str | None] = mapped_column(Text)

    report: Mapped["Report"] = relationship("Report", back_populates="photo_analyses")
