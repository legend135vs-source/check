import uuid
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy import String, Integer, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from app.models.base import Base, UUIDMixin, TimestampMixin


class Report(Base, UUIDMixin, TimestampMixin):
    __tablename__ = "reports"

    vin: Mapped[str | None] = mapped_column(String(17))
    auto_ria_url: Mapped[str | None] = mapped_column(String(1000))
    status: Mapped[str] = mapped_column(String(20), default="pending")
    risk_score: Mapped[int | None] = mapped_column(Integer)
    pdf_url: Mapped[str | None] = mapped_column(String(1000))
    ai_summary: Mapped[str | None] = mapped_column(Text)
    vehicle_data: Mapped[dict | None] = mapped_column(JSONB)
    auction_data: Mapped[dict | None] = mapped_column(JSONB)
    damage_data: Mapped[dict | None] = mapped_column(JSONB)

    photo_analyses: Mapped[list["PhotoAnalysis"]] = relationship("PhotoAnalysis", back_populates="report")
    auction_records: Mapped[list["AuctionRecord"]] = relationship("AuctionRecord", back_populates="report")
