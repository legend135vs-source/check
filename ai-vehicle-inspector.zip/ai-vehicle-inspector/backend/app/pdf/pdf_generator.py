from app.core.config import settings
from app.domain.interfaces.i_pdf_generator import IPDFGenerator
import structlog

logger = structlog.get_logger()


class PDFGenerator(IPDFGenerator):
    async def generate(self, report_data: dict) -> bytes:
        if settings.PDF_ENGINE == "weasyprint":
            return await self._generate_weasyprint(report_data)
        return await self._generate_reportlab(report_data)

    async def _generate_weasyprint(self, data: dict) -> bytes:
        from weasyprint import HTML
        from app.pdf.report_builder import build_html_report
        html_content = build_html_report(data)
        return HTML(string=html_content).write_pdf()

    async def _generate_reportlab(self, data: dict) -> bytes:
        from reportlab.platypus import SimpleDocTemplate
        from io import BytesIO
        buffer = BytesIO()
        doc = SimpleDocTemplate(buffer)
        doc.build([])
        return buffer.getvalue()
