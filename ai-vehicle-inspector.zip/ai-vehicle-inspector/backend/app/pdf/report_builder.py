def build_html_report(data: dict) -> str:
    vin = data.get("vin", "N/A")
    make = data.get("make", "Unknown")
    model = data.get("model", "Unknown")
    year = data.get("year", "")
    risk_score = data.get("risk_score", 0)
    summary = data.get("ai_summary", "")

    return f"""
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>AI Vehicle Inspection Report</title>
<style>
  body {{ font-family: Arial, sans-serif; margin: 40px; color: #333; }}
  .header {{ background: #1a1a2e; color: white; padding: 30px; border-radius: 8px; }}
  .risk-score {{ font-size: 48px; font-weight: bold; color: {'#e74c3c' if risk_score > 70 else '#f39c12' if risk_score > 40 else '#27ae60'}; }}
  .section {{ margin: 24px 0; padding: 20px; border: 1px solid #ddd; border-radius: 8px; }}
  h2 {{ color: #1a1a2e; }}
</style>
</head>
<body>
  <div class="header">
    <h1>AI Vehicle Inspection Report</h1>
    <p>VIN: {vin} | {year} {make} {model}</p>
  </div>
  <div class="section">
    <h2>Risk Score</h2>
    <div class="risk-score">{risk_score}/100</div>
  </div>
  <div class="section">
    <h2>AI Summary</h2>
    <p>{summary}</p>
  </div>
</body>
</html>
"""
