from pydantic import BaseModel
from typing import List, Optional


class DamageItemSchema(BaseModel):
    area: str
    severity: str
    description: str


class SinglePhotoAnalysis(BaseModel):
    photo_url: str
    damages: List[DamageItemSchema]
    overall_condition: str
    ai_notes: str


class PhotoAnalysisResponse(BaseModel):
    analyses: List[SinglePhotoAnalysis]
    total_damage_score: int
    summary: str
