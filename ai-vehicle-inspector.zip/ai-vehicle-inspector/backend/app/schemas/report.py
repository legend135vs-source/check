from pydantic import BaseModel, HttpUrl, field_validator
from typing import Optional, List
from uuid import UUID
from datetime import datetime


class ReportCreateRequest(BaseModel):
    vin: Optional[str] = None
    auto_ria_url: Optional[str] = None
    photo_urls: Optional[List[str]] = None

    @field_validator("vin")
    @classmethod
    def validate_vin(cls, v: Optional[str]) -> Optional[str]:
        if v and len(v) != 17:
            raise ValueError("VIN must be exactly 17 characters")
        return v.upper() if v else v


class ReportStatusResponse(BaseModel):
    id: UUID
    status: str
    message: str


class ReportResponse(BaseModel):
    id: UUID
    vin: Optional[str]
    auto_ria_url: Optional[str]
    status: str
    risk_score: Optional[int]
    pdf_url: Optional[str]
    ai_summary: Optional[str]
    vehicle_data: Optional[dict]
    auction_data: Optional[dict]
    damage_data: Optional[dict]
    created_at: datetime
