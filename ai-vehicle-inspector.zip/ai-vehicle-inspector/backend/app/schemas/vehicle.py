from pydantic import BaseModel
from typing import List, Optional


class VehicleResult(BaseModel):
    id: str
    make: str
    model: str
    year: int
    engine: Optional[str]
    fuel_type: Optional[str]


class VehicleSearchResponse(BaseModel):
    results: List[VehicleResult]
    total: int
