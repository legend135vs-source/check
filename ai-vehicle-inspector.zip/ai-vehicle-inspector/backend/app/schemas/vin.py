from pydantic import BaseModel
from typing import Optional


class VINDecodeResponse(BaseModel):
    vin: str
    make: Optional[str]
    model: Optional[str]
    year: Optional[int]
    engine: Optional[str]
    fuel_type: Optional[str]
    body_type: Optional[str]
    country: Optional[str]
