from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func
from app.models.report import Report
from app.models.brand import Brand
from app.models.ai_prompt import AIPrompt


class AdminService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def get_stats(self) -> dict:
        total_reports = await self.db.scalar(select(func.count(Report.id)))
        done_reports = await self.db.scalar(
            select(func.count(Report.id)).where(Report.status == "done")
        )
        return {
            "total_reports": total_reports or 0,
            "done_reports": done_reports or 0,
            "pending_reports": (total_reports or 0) - (done_reports or 0),
        }

    async def list_brands(self) -> list:
        result = await self.db.execute(select(Brand))
        return [{"id": str(b.id), "name": b.name} for b in result.scalars().all()]

    async def list_prompts(self) -> list:
        result = await self.db.execute(select(AIPrompt))
        return [{"id": str(p.id), "key": p.key, "description": p.description} for p in result.scalars().all()]
