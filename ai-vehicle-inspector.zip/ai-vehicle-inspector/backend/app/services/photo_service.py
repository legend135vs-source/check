from typing import List
from fastapi import UploadFile
from sqlalchemy.ext.asyncio import AsyncSession
from app.schemas.photo import PhotoAnalysisResponse
from app.ai.vision_analyzer import VisionAnalyzer


class PhotoService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.analyzer = VisionAnalyzer()

    async def analyze(self, photos: List[UploadFile]) -> PhotoAnalysisResponse:
        photo_bytes = [await p.read() for p in photos]
        results = await self.analyzer.analyze_batch(photo_bytes)
        total_score = sum(
            {"none": 0, "minor": 1, "moderate": 3, "severe": 5}.get(
                d.severity, 0
            )
            for r in results for d in r.damages
        )
        return PhotoAnalysisResponse(
            analyses=[],
            total_damage_score=min(total_score, 100),
            summary=f"Analyzed {len(photos)} photos. Total damage score: {total_score}.",
        )
