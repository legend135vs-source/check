import uuid
from sqlalchemy.ext.asyncio import AsyncSession
from app.schemas.report import ReportCreateRequest, ReportStatusResponse, ReportResponse
from app.infrastructure.repositories.report_repository import ReportRepository
from app.models.report import Report
import structlog

logger = structlog.get_logger()


class ReportService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.repo = ReportRepository(db)

    async def create_report(self, data: ReportCreateRequest) -> ReportStatusResponse:
        report = Report(
            vin=data.vin,
            auto_ria_url=data.auto_ria_url,
            status="pending",
        )
        self.db.add(report)
        await self.db.commit()
        await self.db.refresh(report)
        logger.info("report_created", report_id=str(report.id))
        return ReportStatusResponse(
            id=report.id,
            status="pending",
            message="Report generation started. Poll GET /api/v1/report/{id} for results.",
        )

    async def get_report(self, report_id: uuid.UUID) -> ReportResponse:
        from app.core.exceptions import ReportNotFoundError
        report = await self.repo.get_by_id(report_id)
        if not report:
            raise ReportNotFoundError(str(report_id))
        return ReportResponse(
            id=report.id,
            vin=report.vin,
            auto_ria_url=report.auto_ria_url,
            status=report.status,
            risk_score=report.risk_score,
            pdf_url=report.pdf_url,
            ai_summary=report.ai_summary,
            vehicle_data=report.vehicle_data,
            auction_data=report.auction_data,
            damage_data=report.damage_data,
            created_at=report.created_at,
        )
