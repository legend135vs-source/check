from sqlalchemy.ext.asyncio import AsyncSession
from app.schemas.vehicle import VehicleSearchResponse


class VehicleService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def search(self, query: str) -> VehicleSearchResponse:
        # TODO: implement full-text search via PostgreSQL
        return VehicleSearchResponse(results=[], total=0)
