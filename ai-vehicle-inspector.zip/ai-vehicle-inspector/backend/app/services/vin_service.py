from sqlalchemy.ext.asyncio import AsyncSession
from app.schemas.vin import VINDecodeResponse
from app.infrastructure.external.vin_decoder_client import VINDecoderClient


class VINService:
    def __init__(self, db: AsyncSession):
        self.db = db
        self.client = VINDecoderClient()

    async def decode(self, vin: str) -> VINDecodeResponse:
        data = await self.client.decode(vin)
        return VINDecodeResponse(
            vin=vin,
            make=data.get("Make"),
            model=data.get("Model"),
            year=data.get("ModelYear"),
            engine=data.get("DisplacementL"),
            fuel_type=data.get("FuelTypePrimary"),
            body_type=data.get("BodyClass"),
            country=data.get("PlantCountry"),
        )
