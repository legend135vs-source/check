#!/usr/bin/env python3
"""Seed database with initial data."""
import asyncio
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine, async_sessionmaker
from app.core.config import settings
from app.models.brand import Brand
from app.models.ai_prompt import AIPrompt

engine = create_async_engine(settings.DATABASE_URL)
AsyncSession_ = async_sessionmaker(engine)

BRANDS = ["Toyota", "Honda", "BMW", "Mercedes-Benz", "Volkswagen", "Ford", "Chevrolet", "Audi", "Hyundai", "Kia"]

PROMPTS = [
    {"key": "full_report", "description": "Full vehicle inspection report"},
    {"key": "vin_analysis", "description": "VIN analysis prompt"},
    {"key": "photo_damage", "description": "Photo damage detection"},
    {"key": "auction_summary", "description": "Auction history summary"},
]


async def seed():
    async with AsyncSession_() as db:
        for name in BRANDS:
            db.add(Brand(name=name))
        for p in PROMPTS:
            db.add(AIPrompt(key=p["key"], description=p["description"], template=f"Template for {p['key']}"))
        await db.commit()
    print("Database seeded successfully!")


if __name__ == "__main__":
    asyncio.run(seed())
