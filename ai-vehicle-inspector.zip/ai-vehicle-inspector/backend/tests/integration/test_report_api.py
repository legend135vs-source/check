import pytest


@pytest.mark.asyncio
async def test_create_report(client):
    response = await client.post("/api/v1/report", json={"vin": "1HGBH41JXMN109186"})
    assert response.status_code == 202
    data = response.json()
    assert data["status"] == "pending"
    assert "id" in data


@pytest.mark.asyncio
async def test_health_check(client):
    response = await client.get("/api/v1/health")
    assert response.status_code == 200
    assert response.json()["status"] == "ok"
