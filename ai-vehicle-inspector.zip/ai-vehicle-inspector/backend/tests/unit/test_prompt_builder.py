import pytest
from app.ai.prompt_builder import PromptBuilder


@pytest.mark.asyncio
async def test_prompt_builder_loads_from_file():
    builder = PromptBuilder(db=None)
    prompt = await builder.build("photo_damage", {})
    assert "damage" in prompt.lower()
