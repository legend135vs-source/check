# API Reference

Base URL: `https://your-backend.railway.app/api/v1`

## Endpoints

### POST /report
Create a new vehicle inspection report.

**Request:**
```json
{
  "vin": "1HGBH41JXMN109186",
  "auto_ria_url": "https://auto.ria.com/...",
  "photo_urls": ["https://..."]
}
```
At least one of `vin`, `auto_ria_url` required.

**Response (202):**
```json
{ "id": "uuid", "status": "pending", "message": "..." }
```

### GET /report/{id}
Get report status and data.

**Response:**
```json
{
  "id": "uuid",
  "status": "pending|processing|done|failed",
  "risk_score": 45,
  "pdf_url": "https://...",
  "ai_summary": "...",
  "vehicle_data": {},
  "auction_data": {},
  "damage_data": {}
}
```

### GET /vin/{vin}
Decode a VIN number.

### POST /photo/analyze
Analyze uploaded photos for damage.

### GET /vehicle/search?q={query}
Search vehicle database.

### GET /health
Health check endpoint.

### GET /{ADMIN_SECRET_PATH}/stats
Admin statistics (hidden route).
