# Architecture — AI Vehicle Inspector

## System Overview

```
Client (Browser)
    │
    ▼
Next.js 15 Frontend (Vercel/Railway)
    │ REST API calls
    ▼
FastAPI Backend (Railway)
    ├── VIN Service ──► NHTSA VIN API
    ├── Auction Service ──► Auto.ria API
    ├── AI Service ──► OpenAI GPT-4o
    ├── PDF Generator ──► WeasyPrint
    ├── Storage Service ──► Cloudflare R2
    └── Cache ──► Redis
         │
         ▼
    PostgreSQL (Railway)
```

## Clean Architecture Layers

### 1. Domain Layer (`app/domain/`)
Pure Python — no framework dependencies.
- `entities/` — dataclasses representing core business objects
- `interfaces/` — abstract base classes (ports) for all external dependencies

### 2. Application Layer (`app/services/`)
Orchestrates use cases. Calls domain interfaces only.
- `report_service.py` — main report orchestration
- `vin_service.py` — VIN decode + enrich
- `photo_service.py` — photo analysis pipeline
- `admin_service.py` — admin CRUD + stats

### 3. Infrastructure Layer (`app/infrastructure/`)
Concrete implementations of domain interfaces.
- `repositories/` — SQLAlchemy database access
- `cache/` — Redis cache
- `storage/` — Cloudflare R2 file storage
- `external/` — HTTP clients for VIN API, Auto.ria

### 4. Delivery Layer (`app/api/`)
FastAPI route handlers. Parse requests, call services, return responses.
Zero business logic.

## AI Pipeline

```
User Input (VIN/URL/Photos)
    │
    ▼
PromptBuilder ──► loads template from DB (ai_prompts table)
    │           ──► injects vehicle context
    ▼
VisionAnalyzer ──► GPT-4o Vision (photos)
    │
    ▼
ReportGenerator ──► GPT-4o Text (full narrative)
    │
    ▼
PDFGenerator ──► WeasyPrint (HTML → PDF)
    │
    ▼
R2Storage ──► upload PDF, return URL
```
