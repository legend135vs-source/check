# Database Schema

## Tables

### brands
| Column | Type | Notes |
|--------|------|-------|
| id | UUID PK | |
| name | VARCHAR(100) | UNIQUE |
| name_uk | VARCHAR(100) | Ukrainian name |
| logo_url | VARCHAR(500) | |
| is_active | BOOLEAN | default true |
| created_at | TIMESTAMPTZ | |
| updated_at | TIMESTAMPTZ | |

### models
| Column | Type | Notes |
|--------|------|-------|
| id | UUID PK | |
| brand_id | UUID FK → brands | |
| name | VARCHAR(100) | |
| year_from | INT | |
| year_to | INT | nullable = current |

### reports
| Column | Type | Notes |
|--------|------|-------|
| id | UUID PK | |
| vin | VARCHAR(17) | nullable |
| auto_ria_url | VARCHAR(1000) | nullable |
| status | VARCHAR(20) | pending/processing/done/failed |
| risk_score | INT | 0-100 |
| pdf_url | VARCHAR(1000) | R2 URL |
| ai_summary | TEXT | |
| vehicle_data | JSONB | |
| auction_data | JSONB | |
| damage_data | JSONB | |

### photo_analyses
| Column | Type | Notes |
|--------|------|-------|
| id | UUID PK | |
| report_id | UUID FK → reports | |
| photo_url | VARCHAR(1000) | R2 URL |
| damage_json | JSONB | structured damage data |
| overall_condition | VARCHAR(50) | |

### auction_records
Stores individual auction entries per report.

### ai_prompts
| Column | Type | Notes |
|--------|------|-------|
| id | UUID PK | |
| key | VARCHAR(100) | UNIQUE |
| template | TEXT | Jinja2 template |
| is_active | BOOLEAN | |
| version | INT | |
