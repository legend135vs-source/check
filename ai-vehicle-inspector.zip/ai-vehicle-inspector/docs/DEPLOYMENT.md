# Deployment Guide

## Railway Setup

### 1. Create Project
1. Go to railway.app → New Project
2. Connect GitHub repo `legend135vs-source/check`

### 2. Add Services
- **PostgreSQL** — Add Plugin
- **Redis** — Add Plugin
- **Backend** — Deploy from `./backend`
- **Frontend** — Deploy from `./frontend`

### 3. Environment Variables

Copy from `.env.example` and fill in real values for each service.

**Backend required vars:**
- `DATABASE_URL` — from Railway Postgres plugin
- `REDIS_URL` — from Railway Redis plugin
- `OPENAI_API_KEY`
- `R2_ACCOUNT_ID`, `R2_ACCESS_KEY_ID`, `R2_SECRET_ACCESS_KEY`

**Frontend required vars:**
- `NEXT_PUBLIC_API_URL` — your backend Railway URL

### 4. Deploy
Push to `main` branch — Railway auto-deploys.
Alembic migrations run automatically before server start.

## Local Development

```bash
# Start DB + Redis
cd docker && docker-compose up -d postgres redis

# Backend
cd backend
cp .env.example .env  # fill in values
pip install -r requirements.txt
alembic upgrade head
python scripts/seed_db.py  # optional: seed brands/prompts
uvicorn app.main:app --reload

# Frontend
cd frontend
cp .env.example .env.local
npm install
npm run dev
```
