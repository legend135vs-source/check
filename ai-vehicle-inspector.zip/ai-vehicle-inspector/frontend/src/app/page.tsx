import { VehicleInputForm } from '@/components/forms/VehicleInputForm'

export default function HomePage() {
  return (
    <main className="min-h-screen bg-gray-50">
      <div className="max-w-2xl mx-auto px-4 py-16">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            AI Vehicle Inspector
          </h1>
          <p className="text-lg text-gray-600">
            Get an instant AI-powered inspection report for any vehicle.
            Enter a VIN, Auto.ria link, or upload photos.
          </p>
        </div>
        <VehicleInputForm />
      </div>
    </main>
  )
}
