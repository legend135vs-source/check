import { ReportViewer } from '@/components/report/ReportViewer'

interface Props {
  params: { id: string }
}

export default function ReportPage({ params }: Props) {
  return <ReportViewer reportId={params.id} />
}
