'use client'

import { useState } from 'react'
import { StatsPanel } from './StatsPanel'

const tabs = ['Stats', 'Brands', 'Prompts', 'Logs']

export function AdminLayout() {
  const [tab, setTab] = useState('Stats')

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-6xl mx-auto px-4 py-8">
        <h1 className="text-2xl font-bold mb-6">Admin Panel</h1>
        <div className="flex gap-2 mb-6">
          {tabs.map(t => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                tab === t ? 'bg-primary text-white' : 'bg-white border text-gray-700 hover:bg-gray-50'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
        {tab === 'Stats' && <StatsPanel />}
        {tab !== 'Stats' && <div className="bg-white rounded-xl border p-8 text-gray-500">Coming soon</div>}
      </div>
    </div>
  )
}
