'use client'

import { useEffect, useState } from 'react'
import { getAdminStats } from '@/lib/api/admin.api'

interface Stats {
  total_reports: number
  done_reports: number
  pending_reports: number
}

export function StatsPanel() {
  const [stats, setStats] = useState<Stats | null>(null)

  useEffect(() => {
    getAdminStats().then(setStats)
  }, [])

  if (!stats) return <div>Loading stats...</div>

  return (
    <div className="grid grid-cols-3 gap-4">
      {Object.entries(stats).map(([key, value]) => (
        <div key={key} className="bg-white rounded-xl border p-6 shadow-sm">
          <div className="text-3xl font-bold text-primary">{value}</div>
          <div className="text-sm text-gray-600 mt-1 capitalize">{key.replace(/_/g, ' ')}</div>
        </div>
      ))}
    </div>
  )
}
