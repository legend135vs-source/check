'use client'

import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { useRouter } from 'next/navigation'
import { reportSchema, type ReportFormData } from '@/lib/validators/report.schema'
import { useReportGeneration } from '@/hooks/useReportGeneration'

export function VehicleInputForm() {
  const router = useRouter()
  const { createReport, isLoading } = useReportGeneration()

  const form = useForm<ReportFormData>({
    resolver: zodResolver(reportSchema),
  })

  const onSubmit = async (data: ReportFormData) => {
    const report = await createReport(data)
    if (report?.id) {
      router.push(`/report/${report.id}`)
    }
  }

  return (
    <form onSubmit={form.handleSubmit(onSubmit)} className="bg-white rounded-xl shadow-sm border p-8 space-y-6">
      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">VIN Number</label>
        <input
          {...form.register('vin')}
          placeholder="1HGBH41JXMN109186"
          className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
        {form.formState.errors.vin && (
          <p className="mt-1 text-sm text-red-600">{form.formState.errors.vin.message}</p>
        )}
      </div>

      <div className="text-center text-gray-400 text-sm">— or —</div>

      <div>
        <label className="block text-sm font-medium text-gray-700 mb-2">Auto.ria Link</label>
        <input
          {...form.register('auto_ria_url')}
          placeholder="https://auto.ria.com/auto_..."
          className="w-full border border-gray-300 rounded-lg px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-primary"
        />
      </div>

      <button
        type="submit"
        disabled={isLoading}
        className="w-full bg-primary hover:bg-primary-hover text-white font-semibold py-3 rounded-lg transition-colors disabled:opacity-50"
      >
        {isLoading ? 'Generating Report...' : 'Generate Inspection Report'}
      </button>
    </form>
  )
}
