'use client'

import { useEffect, useState } from 'react'
import { getReport } from '@/lib/api/report.api'
import { RiskScoreBadge } from './RiskScoreBadge'
import { DownloadPdfButton } from '@/components/shared/DownloadPdfButton'
import type { ReportData } from '@/types/report.types'

interface Props {
  reportId: string
}

export function ReportViewer({ reportId }: Props) {
  const [report, setReport] = useState<ReportData | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const poll = async () => {
      const data = await getReport(reportId)
      setReport(data)
      if (data.status === 'pending' || data.status === 'processing') {
        setTimeout(poll, 3000)
      } else {
        setLoading(false)
      }
    }
    poll()
  }, [reportId])

  if (loading && !report) return <div className="p-8 text-center">Loading report...</div>

  if (!report) return <div className="p-8 text-center text-red-600">Report not found.</div>

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="flex items-center justify-between mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Inspection Report</h1>
        {report.pdf_url && <DownloadPdfButton url={report.pdf_url} />}
      </div>

      {report.risk_score !== null && report.risk_score !== undefined && (
        <RiskScoreBadge score={report.risk_score} />
      )}

      {report.status === 'pending' || report.status === 'processing' ? (
        <div className="mt-6 p-4 bg-blue-50 rounded-lg text-blue-700">
          Generating report... This may take 30-60 seconds.
        </div>
      ) : null}

      {report.ai_summary && (
        <div className="mt-6 p-6 bg-white border rounded-xl shadow-sm">
          <h2 className="text-lg font-semibold mb-3">AI Summary</h2>
          <p className="text-gray-700">{report.ai_summary}</p>
        </div>
      )}
    </div>
  )
}
