interface Props {
  score: number
}

export function RiskScoreBadge({ score }: Props) {
  const level = score > 70 ? 'critical' : score > 40 ? 'high' : score > 20 ? 'medium' : 'low'
  const colors = {
    low: 'bg-green-100 text-green-800',
    medium: 'bg-yellow-100 text-yellow-800',
    high: 'bg-orange-100 text-orange-800',
    critical: 'bg-red-100 text-red-800',
  }

  return (
    <div className={`inline-flex items-center gap-2 px-4 py-2 rounded-full font-semibold ${colors[level]}`}>
      <span className="text-2xl font-bold">{score}</span>
      <span className="text-sm uppercase tracking-wide">Risk Score · {level}</span>
    </div>
  )
}
