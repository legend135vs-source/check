interface Props {
  url: string
}

export function DownloadPdfButton({ url }: Props) {
  return (
    <a
      href={url}
      download
      className="inline-flex items-center gap-2 bg-primary text-white px-4 py-2 rounded-lg text-sm font-medium hover:bg-primary-hover transition-colors"
    >
      Download PDF Report
    </a>
  )
}
