import { useState } from 'react'
import { createReport } from '@/lib/api/report.api'
import type { ReportFormData } from '@/lib/validators/report.schema'

export function useReportGeneration() {
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const generate = async (data: ReportFormData) => {
    setIsLoading(true)
    setError(null)
    try {
      const result = await createReport(data)
      return result
    } catch (e: any) {
      setError(e.message || 'Failed to create report')
      return null
    } finally {
      setIsLoading(false)
    }
  }

  return { createReport: generate, isLoading, error }
}
