import { useState } from 'react'
import { decodeVin } from '@/lib/api/vin.api'

export function useVinLookup() {
  const [isLoading, setIsLoading] = useState(false)
  const [data, setData] = useState(null)

  const lookup = async (vin: string) => {
    setIsLoading(true)
    try {
      const result = await decodeVin(vin)
      setData(result)
      return result
    } finally {
      setIsLoading(false)
    }
  }

  return { lookup, data, isLoading }
}
