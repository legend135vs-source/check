import apiClient from './client'

const adminPath = '/api/v1/admin-x7k2'

export const getAdminStats = async () => {
  const res = await apiClient.get(`${adminPath}/stats`)
  return res.data
}
