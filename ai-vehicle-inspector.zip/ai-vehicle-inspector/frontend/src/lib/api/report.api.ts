import apiClient from './client'
import type { ReportFormData } from '@/lib/validators/report.schema'
import type { ReportData, ReportStatusResponse } from '@/types/report.types'

export const createReport = async (data: ReportFormData): Promise<ReportStatusResponse> => {
  const res = await apiClient.post('/api/v1/report', data)
  return res.data
}

export const getReport = async (id: string): Promise<ReportData> => {
  const res = await apiClient.get(`/api/v1/report/${id}`)
  return res.data
}
