import apiClient from './client'

export const decodeVin = async (vin: string) => {
  const res = await apiClient.get(`/api/v1/vin/${vin}`)
  return res.data
}
