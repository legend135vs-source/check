export const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000'
export const REPORT_POLL_INTERVAL_MS = 3000
export const MAX_PHOTOS = 20
export const MAX_PHOTO_SIZE_MB = 10
