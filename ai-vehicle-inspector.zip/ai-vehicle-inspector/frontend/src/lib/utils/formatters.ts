export const formatDate = (date: string): string =>
  new Date(date).toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })

export const formatRiskLevel = (score: number): string => {
  if (score > 70) return 'Critical'
  if (score > 40) return 'High'
  if (score > 20) return 'Medium'
  return 'Low'
}

export const formatOdometer = (km: number): string =>
  new Intl.NumberFormat('en-US').format(km) + ' km'
