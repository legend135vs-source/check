import { z } from 'zod'

export const reportSchema = z.object({
  vin: z
    .string()
    .length(17, 'VIN must be exactly 17 characters')
    .optional()
    .or(z.literal('')),
  auto_ria_url: z
    .string()
    .url('Enter a valid Auto.ria URL')
    .optional()
    .or(z.literal('')),
}).refine(
  (data) => data.vin || data.auto_ria_url,
  { message: 'Enter a VIN or Auto.ria link' }
)

export type ReportFormData = z.infer<typeof reportSchema>
