import { z } from 'zod'

export const vinSchema = z.object({
  vin: z.string().length(17, 'VIN must be 17 characters').regex(/^[A-HJ-NPR-Z0-9]{17}$/, 'Invalid VIN format'),
})
