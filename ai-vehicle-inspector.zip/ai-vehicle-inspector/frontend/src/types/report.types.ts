export interface ReportStatusResponse {
  id: string
  status: string
  message: string
}

export interface ReportData {
  id: string
  vin: string | null
  auto_ria_url: string | null
  status: 'pending' | 'processing' | 'done' | 'failed'
  risk_score: number | null
  pdf_url: string | null
  ai_summary: string | null
  vehicle_data: Record<string, unknown> | null
  auction_data: Record<string, unknown> | null
  damage_data: Record<string, unknown> | null
  created_at: string
}
