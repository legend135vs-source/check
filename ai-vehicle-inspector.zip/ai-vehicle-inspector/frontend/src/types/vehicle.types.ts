export interface Vehicle {
  id: string
  make: string
  model: string
  year: number
  engine: string | null
  fuel_type: string | null
  body_type: string | null
  mileage: number | null
}
